# CertRadar discovery implementation

## Audit
The original project was a buildless HTML page with six illustrative records, browser-local saves, and no server or persistent database. Its original card layout and styles remain intact. This change adds a Python standard-library service and SQLite store. It does not claim to implement the earlier proposed Next.js/PostgreSQL/Firebase stack.

## Run
From the repository root:

```
python3 -m backend.server
python3 -m backend.worker
```

The server listens on 127.0.0.1:4174. Use a production TLS reverse proxy and supervised processes when hosting it. The worker checks due sources every minute; each source defaults to six hours. Failed sources retry after 5, 10, 20, 40, 80, 160, then 320/360 minutes. ETags and Last-Modified reduce repeated transfers. Per-source leases prevent overlapping scans. A crashed claim becomes available after five minutes.

Set CERTRADAR_ADMIN_TOKEN to a randomly generated secret of at least 32 characters, injected through your deployment secret manager. Admin APIs fail closed without it. Open /admin and enter the token; it stays in page memory, never local storage. Rate limits are per process and client address; configure distributed rate limiting at the production proxy. The built-in HTTP service is a local development entrypoint, not a hardened production server.

CERTRADAR_DB selects the SQLite path (default data/certradar.sqlite). Preserve this directory on a persistent volume and back it up. Schema initialization uses CREATE IF NOT EXISTS. Future schema changes require versioned migrations.

On this machine Python needs SSL_CERT_FILE=/etc/ssl/cert.pem to use the system's trust store. Certificate validation must remain enabled.

## Sources and verification
backend/providers.json is the reviewed source registry. Add official RSS feeds or compatible catalog endpoints there; core parsing does not change for those formats. No arbitrary page crawling is enabled. Review provider terms and documented access before enabling new sources. Source hosts and redirects are allowlisted. Feed/catalog evidence is stored alongside each finding. URL canonicalization deduplicates tracking variants; source changes preserve history and reset verification to pending. Similar titles across different URLs are not yet automatically merged.

AWS training announcements and Microsoft Learn catalog are the two implemented integrations. The remaining requested providers are NOT monitored. Unknown deadlines, eligibility, certificate availability, registration URLs, and prices stay unknown. Keyword categories are heuristic and reviewable, not AI-verified facts. Admin approval records a human review; official-source discovery alone does not imply registration is open or a certificate is free. No findings are automatically asserted to be fully verified.

## Notifications
Publication produces a deduplicated in-app event. SMTP_HOST, SMTP_PORT (465 default), SMTP_FROM, optional SMTP_USER/SMTP_PASSWORD, and HTTPS PUBLIC_ORIGIN enable confirmation email and digest delivery. Subscriptions require confirmation through a private link. That link also manages preferences/unsubscribe. SMTP is not configured in this workspace. No real email was sent. Delivery claims prevent concurrent duplicates; ambiguous failures are held for operator review instead of automatic resend. A production provider with idempotency keys is recommended before volume rollout.

Deadline, registration-open, and reopen notifications require structured verified status/date extraction and are not enabled. Browser push is not implemented.

## Hosting status
The existing Sites deployment supports static assets and Cloudflare Workers, not this Python/SQLite service. The static UI can consume the same-origin /api routes when served by this backend. On the current static host it explicitly reports that discovery is not connected and retains the labeled sample catalog. The backend and its persistent worker need a compatible runtime, durable storage, TLS, and secrets, or a port to Sites Worker/D1 before cloud activation. A local worker is not represented as an active cloud schedule.

## Remaining work before production completion
- Deploy the backend and supervised scheduler with persistent storage.
- Configure authenticated end-user identity and production admin roles (current admin uses an environment token).
- Configure email delivery and test confirmation/digest delivery against a real inbox.
- Validate and onboard remaining providers; add provider-specific structured extraction and verification rules.
- Add deadline/reopening event generation, richer eligibility/deadline filters, listing corrections, source addition UI, and per-user notification history.
- Add migration versioning, distributed rate limits, service monitoring, and browser/responsive QA.

The platform is a tested first implementation stage, not a completed global discovery service.
