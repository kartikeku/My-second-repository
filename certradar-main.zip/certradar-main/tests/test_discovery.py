import unittest,tempfile,os,json
from unittest.mock import patch
from backend import discovery as d
from backend.server import review
from backend.notifications import deliver
class DiscoveryTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.env=patch.dict(os.environ,{'CERTRADAR_DB':self.temp.name+'/test.sqlite'});self.env.start();d.init();d.seed();self.source={'provider':'AWS','url':d.SOURCES[0][1],'kind':'rss'}
  self.item={'title':'Test training','description':'Cloud learning','source_url':'https://aws.amazon.com/training/test?utm_source=test','program_type':'Courses','evidence':'test fixture'}
 def tearDown(self):self.env.stop();self.temp.cleanup()
 def test_dedupe_and_history(self):
  with d.database() as db:
   self.assertEqual(d.upsert(db,self.item,self.source),'new');self.assertEqual(d.upsert(db,self.item,self.source),'unchanged')
   self.item['description']='Changed';self.assertEqual(d.upsert(db,self.item,self.source),'updated');self.assertEqual(db.execute('SELECT count(*) FROM history').fetchone()[0],1)
 def test_no_unverified_notification(self):
  with d.database() as db:
   d.upsert(db,self.item,self.source);row=db.execute('SELECT * FROM opportunities').fetchone();self.assertEqual(row['verification'],'Pending Verification');self.assertEqual(row['price'],'Unknown');self.assertIsNone(row['deadline']);self.assertEqual(db.execute('SELECT count(*) FROM notifications').fetchone()[0],0)
   review(db,row['id'],'approve');review(db,row['id'],'approve');self.assertEqual(db.execute('SELECT count(*) FROM notifications').fetchone()[0],1)
   self.item['description']='Changed';d.upsert(db,self.item,self.source);self.assertEqual(db.execute('SELECT verification FROM opportunities').fetchone()[0],'Pending Verification')
 def test_unofficial_rejected(self):
  self.item['source_url']='https://evil.example/fake'
  with d.database() as db:self.assertEqual(d.upsert(db,self.item,self.source),'skipped')
 def test_network_allowlist(self):
  with self.assertRaises(ValueError):d.get('https://127.0.0.1/private')
 def test_retry_and_due_gate(self):
  with patch.object(d,'get',side_effect=ValueError('upstream failed')) as get:
   self.assertEqual(len(d.scan()),2);self.assertEqual(d.scan(),[]);self.assertEqual(get.call_count,2)
  with d.database() as db:self.assertTrue(all(r['failures']==1 and r['next_scan'] for r in db.execute('SELECT * FROM sources')))
 def test_feed_parser(self):
  rows=list(d.parse(b'<rss><channel><item><title>New cloud training</title><link>https://aws.amazon.com/test</link><description>Learn skills</description></item></channel></rss>',self.source));self.assertEqual(len(rows),1)
 def test_email_requires_configuration(self):
  with patch.dict(os.environ,{},clear=True):self.assertEqual(deliver()['status'],'blocked')
 def test_email_deduplicated(self):
  with d.database() as db:
   d.upsert(db,self.item,self.source);row=db.execute('SELECT * FROM opportunities').fetchone();review(db,row['id'],'approve')
   db.execute("INSERT INTO subscribers(id,email,token_hash,confirmed,frequency) VALUES('test','test@example.com','fixture',1,'immediate')")
  with patch.dict(os.environ,{'SMTP_HOST':'smtp.example.com','SMTP_FROM':'test@example.com'}),patch('backend.notifications.smtplib.SMTP_SSL') as smtp:
   self.assertEqual(deliver()['sent'],1);self.assertEqual(deliver()['sent'],0);self.assertEqual(smtp.return_value.__enter__.return_value.send_message.call_count,1)
 def test_subscriptions_private_token(self):
  from backend.subscriptions import manage
  import hashlib
  with d.database() as db:db.execute("INSERT INTO subscribers(id,email,token_hash) VALUES(?,?,?)",('s','test@example.com',hashlib.sha256(b'private').hexdigest()))
  with self.assertRaises(ValueError):manage({'token':'wrong'})
  manage({'token':'private','action':'confirm','frequency':'weekly'})
  with d.database() as db:self.assertEqual(db.execute('SELECT confirmed FROM subscribers').fetchone()[0],1)
  manage({'token':'private','action':'unsubscribe'})
  with d.database() as db:self.assertEqual(db.execute('SELECT confirmed FROM subscribers').fetchone()[0],0)
if __name__=='__main__':unittest.main()
