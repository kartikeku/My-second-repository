"""Local service; deploy behind TLS and a process manager for production."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlsplit,parse_qs
import json, os, secrets, hashlib, time, threading
from pathlib import Path
from backend.subscriptions import subscribe,manage
from backend.discovery import database,init,seed,scan,now,ROOT,SOURCES
RATE={}; LOCK=threading.Lock()

def review(db,identity,decision):
    row=db.execute('SELECT * FROM opportunities WHERE id=?',(identity,)).fetchone()
    if not row:raise ValueError('Listing not found')
    # Approval is an explicit human assertion after reviewing saved source evidence.
    status='Verified' if decision=='approve' else 'Rejected'
    db.execute('INSERT INTO history(opportunity_id,recorded_at,snapshot) VALUES(?,?,?)',(identity,now(),json.dumps(dict(row))))
    db.execute('UPDATE opportunities SET verification=?,verified_at=?,updated_at=? WHERE id=?',(status,now() if decision=='approve' else None,now(),identity))
    if decision=='approve':
        key=identity+':'+row['fingerprint']
        db.execute('INSERT OR IGNORE INTO notifications(event_key,opportunity_id,kind,created_at,payload) VALUES(?,?,?,?,?)',(key,identity,'published',now(),json.dumps({'title':row['title'],'provider':row['provider'],'category':row['category']})))

class Handler(BaseHTTPRequestHandler):
    def send(self,obj,status=200):
        raw=json.dumps(obj).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(raw)
    def admin(self):
        token=os.environ.get('CERTRADAR_ADMIN_TOKEN','')
        return len(token)>=32 and secrets.compare_digest(self.headers.get('Authorization',''),'Bearer '+token)
    def limited(self):
        key=self.client_address[0]; t=time.monotonic()
        with LOCK:
            for stale in [k for k,v in RATE.items() if t-v[0]>60]:RATE.pop(stale,None)
            start,count=RATE.get(key,(t,0));RATE[key]=(start,count+1)
        return count>=120
    def do_GET(self):
        if self.limited():return self.send({'error':'Rate limit exceeded'},429)
        url=urlsplit(self.path);query=parse_qs(url.query)
        if url.path.startswith('/api/admin') and not self.admin():return self.send({'error':'Administrator authentication required'},401)
        with database() as db:
            if url.path=='/api/health':return self.send({'database':'connected','email':'configured' if os.environ.get('SMTP_HOST') else 'not configured','scheduler':'external worker required'})
            if url.path=='/api/opportunities':
                rows=[dict(r) for r in db.execute("SELECT * FROM opportunities WHERE verification='Verified' ORDER BY discovered_at DESC LIMIT 1000")]
                for key in ['provider','category','program_type','price','eligibility']:
                    if query.get(key):rows=[r for r in rows if query[key][0].lower() in (r[key] or '').lower()]
                q=query.get('q',[''])[0].lower()
                rows=[r for r in rows if q in (r['title']+' '+r['provider']+' '+r['description']+' '+r['skills']).lower()]
                if query.get('sort')==['deadline']:rows.sort(key=lambda r:r['deadline'] or '9999')
                for r in rows:r.pop('evidence',None)
                return self.send({'opportunities':rows})
            if url.path=='/api/notifications':
                rows=[dict(r) for r in db.execute('SELECT n.* FROM notifications n JOIN opportunities o ON o.id=n.opportunity_id WHERE o.verification=\'Verified\' ORDER BY n.id DESC LIMIT 100')]
                return self.send({'notifications':rows})
            if url.path=='/api/admin':
                sources=[dict(r) for r in db.execute('SELECT * FROM sources')]
                counts={r[0]:r[1] for r in db.execute('SELECT verification,count(*) FROM opportunities GROUP BY verification')}
                return self.send({'sources':sources,'counts':counts,'logs':[dict(r) for r in db.execute('SELECT * FROM logs ORDER BY id DESC LIMIT 50')],'pending':[dict(r) for r in db.execute("SELECT * FROM opportunities WHERE verification='Pending Verification' ORDER BY discovered_at DESC LIMIT 100")]})
            if url.path.startswith('/api/'):return self.send({'error':'Not found'},404)
        file=ROOT/'dist'/('admin.html' if url.path in ['/admin','/admin.html'] else 'subscription.html' if url.path=='/subscription' else 'index.html')
        self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(file.read_bytes())
    def do_POST(self):
        if self.limited():return self.send({'error':'Rate limit exceeded'},429)
        if self.path.startswith('/api/admin') and not self.admin():return self.send({'error':'Administrator authentication required'},401)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>10000:return self.send({'error':'Request too large'},413)
            body=json.loads(self.rfile.read(length))
            if self.path=='/api/subscribe':return self.send(subscribe(body))
            if self.path=='/api/subscription':return self.send(manage(body))
            with database() as db:
                if self.path=='/api/admin/review':
                    if body.get('decision') not in ['approve','reject']:raise ValueError('Invalid review decision')
                    review(db,body['id'],body['decision']);return self.send({'ok':True})
                if self.path=='/api/admin/source':
                    interval=float(body.get('interval_hours',6))
                    if not 1<=interval<=168:raise ValueError('Interval must be between 1 and 168 hours')
                    db.execute('UPDATE sources SET enabled=?,interval_hours=? WHERE id=?',(int(bool(body['enabled'])),interval,int(body['id'])))
                    return self.send({'ok':True})
            if self.path=='/api/admin/scan':
                # Due-time gate applies to manual runs too, preventing request floods.
                return self.send({'results':scan()})
            return self.send({'error':'Not found'},404)
        except (ValueError,KeyError,TypeError) as exc:return self.send({'error':str(exc)},400)
        except Exception:return self.send({'error':'Operation failed; check service logs'},500)

if __name__=='__main__':
    init();seed();ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('PORT','4174'))),Handler).serve_forever()
