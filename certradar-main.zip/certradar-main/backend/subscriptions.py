import hashlib,json,secrets,re,os,smtplib
from email.message import EmailMessage
from backend.discovery import database

def subscribe(body):
    if not os.environ.get('SMTP_HOST') or not os.environ.get('PUBLIC_ORIGIN'):raise ValueError('Email subscription is unavailable until SMTP and public origin are configured')
    email=body.get('email','').strip().lower()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or len(email)>254:raise ValueError('Valid email required')
    if body.get('frequency','daily') not in ['immediate','daily','weekly']:raise ValueError('Invalid notification frequency')
    for key in ['providers','categories']:
        if not isinstance(body.get(key,[]),list) or any(not isinstance(x,str) or len(x)>100 for x in body.get(key,[])):raise ValueError('Invalid preferences')
    token=secrets.token_urlsafe(32); digest=hashlib.sha256(token.encode()).hexdigest()
    with database() as db:
        if db.execute('SELECT 1 FROM subscribers WHERE email=?',(email,)).fetchone():return {'message':'If eligible, a confirmation email will arrive. Existing subscriptions can be managed with their private link.'}
        db.execute('INSERT INTO subscribers(id,email,token_hash,providers,categories,frequency) VALUES(?,?,?,?,?,?)',(secrets.token_hex(16),email,digest,json.dumps(body.get('providers',[])),json.dumps(body.get('categories',[])),body.get('frequency','daily')))
    origin=os.environ['PUBLIC_ORIGIN'].rstrip('/')
    if not origin.startswith('https://'):raise ValueError('PUBLIC_ORIGIN requires HTTPS')
    message=EmailMessage();message['From']=os.environ['SMTP_FROM'];message['To']=email;message['Subject']='Confirm CertRadar updates'
    message.set_content('Confirm your notification preferences using your private link:\n'+origin+'/subscription#'+token+'\nKeep this link to update preferences or unsubscribe.')
    try:
        with smtplib.SMTP_SSL(os.environ['SMTP_HOST'],int(os.environ.get('SMTP_PORT','465')),timeout=20) as smtp:
            if os.environ.get('SMTP_USER'):smtp.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD'])
            smtp.send_message(message)
    except Exception:
        with database() as db:db.execute('DELETE FROM subscribers WHERE email=? AND confirmed=0',(email,))
        raise ValueError('Confirmation email could not be sent; please retry later')
    return {'message':'Check your email to confirm your subscription.'}

def manage(body):
    digest=hashlib.sha256(body.get('token','').encode()).hexdigest()
    with database() as db:
        row=db.execute('SELECT * FROM subscribers WHERE token_hash=?',(digest,)).fetchone()
        if not row:raise ValueError('Invalid subscription link')
        if body.get('action')=='unsubscribe':db.execute('UPDATE subscribers SET confirmed=0 WHERE id=?',(row['id'],));return {'message':'Unsubscribed.'}
        frequency=body.get('frequency',row['frequency'])
        if frequency not in ['immediate','daily','weekly']:raise ValueError('Invalid frequency')
        providers=body.get('providers',json.loads(row['providers']));categories=body.get('categories',json.loads(row['categories']))
        if any(not isinstance(v,list) or len(v)>50 or any(not isinstance(x,str) or len(x)>100 for x in v) for v in [providers,categories]):raise ValueError('Invalid preferences')
        db.execute('UPDATE subscribers SET confirmed=1,frequency=?,providers=?,categories=? WHERE id=?',(frequency,json.dumps(providers),json.dumps(categories),row['id']))
    return {'message':'Subscription confirmed. Preferences saved.'}
