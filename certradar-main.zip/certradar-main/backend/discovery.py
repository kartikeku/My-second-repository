"""Conservative official-source discovery. All announcement findings require review."""
import datetime as dt, hashlib, json, re, sqlite3, urllib.request, urllib.error, urllib.parse, xml.etree.ElementTree as ET, os
from pathlib import Path
UTC=dt.timezone.utc
ROOT=Path(__file__).resolve().parent.parent

def now(): return dt.datetime.now(UTC).isoformat()
class Connection(sqlite3.Connection):
    def __exit__(self,*args):
        try:return super().__exit__(*args)
        finally:self.close()

def database():
    path=os.environ.get('CERTRADAR_DB',str(ROOT/'data/certradar.sqlite'))
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(path,timeout=30,factory=Connection); db.row_factory=sqlite3.Row
    return db

def init():
    with database() as db: db.executescript((ROOT/'backend/schema.sql').read_text())

def clean(value): return re.sub(r'\s+',' ',re.sub('<[^>]*>',' ',value or '')).strip()
def canonical(url):
    p=urllib.parse.urlsplit(url)
    if p.scheme!='https' or not p.hostname or p.username or p.password: raise ValueError('HTTPS official URL required')
    return urllib.parse.urlunsplit(('https',p.netloc.lower(),p.path or '/',urllib.parse.urlencode([(k,v) for k,v in urllib.parse.parse_qsl(p.query) if not k.startswith('utm_')]),''))

# URLs must be explicitly reviewed. Arbitrary admin-provided network targets are never fetched.
SOURCES=[(p['provider'],p['url'],p['kind']) for p in json.loads((ROOT/'backend/providers.json').read_text())]
ALLOWED={urllib.parse.urlsplit(url).hostname for _,url,_ in SOURCES}
class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        if urllib.parse.urlsplit(newurl).hostname not in ALLOWED or not newurl.startswith('https://'): raise ValueError('Unapproved redirect')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def get(url,headers=None):
    if urllib.parse.urlsplit(canonical(url)).hostname not in ALLOWED: raise ValueError('Source host has not been approved')
    req=urllib.request.Request(url,headers={'User-Agent':'CertRadar/1.0 official-feed-reader',**(headers or {})})
    try:
        with urllib.request.build_opener(SafeRedirect).open(req,timeout=35) as r:
            raw=r.read(25_000_001)
            if len(raw)>25_000_000: raise ValueError('Source exceeds size limit')
            return r.status,raw,dict(r.headers)
    except urllib.error.HTTPError as e:
        if e.code==304:return 304,b'',{}
        raise

def classify(title,description):
    text=(title+' '+description).lower()
    for key,category in [('cyber','Cybersecurity'),('security','Cybersecurity'),('machine learning','AI & Machine Learning'),('generative','AI & Machine Learning'),('data','Data Science'),('cloud','Cloud Computing')]:
        if key in text:return category
    return 'Software Engineering'

def parse(raw,source):
    if source['kind']=='catalog':
        doc=json.loads(raw)
        for item in [*doc.get('modules',[]), *doc.get('learningPaths',[]), *doc.get('certifications',[])]:
            if not item.get('title') or not item.get('url'):continue
            yield {'title':clean(item['title']),'description':clean(item.get('summary',''))[:2000],'source_url':item['url'],'program_type':'Certifications' if item.get('type')=='certification' else 'Courses','evidence':json.dumps(item,ensure_ascii=False)}
    else:
        root=ET.fromstring(raw)
        for item in root.findall('.//item'):
            title=clean(item.findtext('title')); description=clean(item.findtext('description'))
            if not re.search(r'learn|course|certif|training|skill|bootcamp|student|challenge',title+' '+description,re.I):continue
            yield {'title':title,'description':description[:2000],'source_url':item.findtext('link'),'program_type':'Learning Programs','evidence':ET.tostring(item,encoding='unicode')}

def upsert(db,item,source):
    url=canonical(item['source_url'])
    host=urllib.parse.urlsplit(url).hostname
    official=urllib.parse.urlsplit(source['url']).hostname
    if host!=official: return 'skipped'
    if not item['title']:return 'skipped'
    identity=hashlib.sha256(url.encode()).hexdigest()[:24]
    payload={'title':item['title'],'provider':source['provider'],'category':classify(item['title'],item['description']),'description':item['description'],'program_type':item['program_type'],'source_url':url,'evidence':item['evidence']}
    fingerprint=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
    old=db.execute('SELECT * FROM opportunities WHERE id=?',(identity,)).fetchone()
    if old and old['fingerprint']==fingerprint:return 'unchanged'
    timestamp=now()
    if old:
        db.execute('INSERT INTO history(opportunity_id,recorded_at,snapshot) VALUES(?,?,?)',(identity,timestamp,json.dumps(dict(old))))
        db.execute('UPDATE opportunities SET title=?,description=?,category=?,evidence=?,fingerprint=?,updated_at=?,verification=?,verified_at=NULL WHERE id=?',(payload['title'],payload['description'],payload['category'],payload['evidence'],fingerprint,timestamp,'Pending Verification',identity))
    else:
        db.execute('INSERT INTO opportunities(id,title,provider,category,description,program_type,source_url,discovered_at,updated_at,evidence,fingerprint) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(identity,payload['title'],payload['provider'],payload['category'],payload['description'],payload['program_type'],url,timestamp,timestamp,payload['evidence'],fingerprint))
    return 'updated' if old else 'new'

def scan(source_id=None):
    with database() as db:
        sources=db.execute('SELECT * FROM sources WHERE enabled=1 AND (? IS NULL OR id=?) AND (next_scan IS NULL OR next_scan<=?) AND (lease_until IS NULL OR lease_until<=?)',(source_id,source_id,now(),now())).fetchall()
    results=[]
    for source in sources:
        with database() as db:
            claim=db.execute('UPDATE sources SET lease_until=? WHERE id=? AND (lease_until IS NULL OR lease_until<=?)',((dt.datetime.now(UTC)+dt.timedelta(minutes=5)).isoformat(),source['id'],now()))
            if claim.rowcount!=1:continue
        try:
            headers={}
            if source['etag']:headers['If-None-Match']=source['etag']
            if source['modified']:headers['If-Modified-Since']=source['modified']
            status,raw,response_headers=get(source['url'],headers)
            counts={'new':0,'updated':0,'unchanged':0,'skipped':0}
            with database() as db:
                if status!=304:
                    for item in parse(raw,source):counts[upsert(db,item,source)]+=1
                next_scan=(dt.datetime.now(UTC)+dt.timedelta(hours=source['interval_hours'])).isoformat()
                db.execute('UPDATE sources SET last_success=?,next_scan=?,failures=0,error=NULL,lease_until=NULL,etag=COALESCE(?,etag),modified=COALESCE(?,modified) WHERE id=?',(now(),next_scan,response_headers.get('ETag'),response_headers.get('Last-Modified'),source['id']))
                db.execute('INSERT INTO logs(source_id,time,status,detail) VALUES(?,?,?,?)',(source['id'],now(),'success',json.dumps(counts)))
            results.append({'provider':source['provider'],**counts})
        except Exception as exc:
            delay=min(360,5*2**min(source['failures'],6))
            with database() as db:
                db.execute('UPDATE sources SET failures=failures+1,error=?,lease_until=NULL,next_scan=? WHERE id=?',(str(exc)[:500],(dt.datetime.now(UTC)+dt.timedelta(minutes=delay)).isoformat(),source['id']))
                db.execute('INSERT INTO logs(source_id,time,status,detail) VALUES(?,?,?,?)',(source['id'],now(),'error',str(exc)[:500]))
            results.append({'provider':source['provider'],'error':str(exc)})
    return results

def seed():
    with database() as db:
        for provider,url,kind in SOURCES:db.execute('INSERT OR IGNORE INTO sources(provider,url,kind) VALUES(?,?,?)',(provider,url,kind))

if __name__=='__main__':
    init();seed();print(json.dumps(scan(),indent=2))
