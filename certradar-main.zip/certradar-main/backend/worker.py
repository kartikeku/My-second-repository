"""Run every minute under a supervisor. Each source enforces its own due time."""
import time,logging
from backend.discovery import init,seed,scan
from backend.notifications import deliver

def tick():
    results=scan();deliver();return results
if __name__=='__main__':
    init();seed()
    while True:
        try:logging.warning('%s',tick())
        except Exception:logging.exception('Worker tick failed')
        time.sleep(60)
