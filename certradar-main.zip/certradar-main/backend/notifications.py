"""Confirmed subscribers only; SMTP credentials are environment-only.
Ambiguous SMTP failures are held for review rather than retried (avoids spam).
"""
import os,json,smtplib,datetime as dt
from email.message import EmailMessage
from backend.discovery import database,now,UTC

def deliver():
    if not os.environ.get('SMTP_HOST'):return {'status':'blocked','reason':'SMTP not configured'}
    count=0
    with database() as db:
        subscribers=db.execute('SELECT * FROM subscribers WHERE confirmed=1').fetchall()
    for sub in subscribers:
        hours={'immediate':0,'daily':24,'weekly':168}.get(sub['frequency'],24)
        if sub['last_sent'] and (dt.datetime.now(UTC)-dt.datetime.fromisoformat(sub['last_sent'])).total_seconds()<hours*3600:continue
        with database() as db:
            events=db.execute("SELECT n.* FROM notifications n JOIN opportunities o ON o.id=n.opportunity_id WHERE o.verification='Verified' AND NOT EXISTS(SELECT 1 FROM deliveries d WHERE d.notification_id=n.id AND d.subscriber_id=?) ORDER BY n.id LIMIT 100",(sub['id'],)).fetchall()
            selected=[]
            for event in events:
                payload=json.loads(event['payload'])
                if json.loads(sub['providers']) and payload['provider'] not in json.loads(sub['providers']):continue
                if json.loads(sub['categories']) and payload['category'] not in json.loads(sub['categories']):continue
                claim=db.execute('INSERT OR IGNORE INTO deliveries(subscriber_id,notification_id,status) VALUES(?,?,?)',(sub['id'],event['id'],'sending'))
                if claim.rowcount:selected.append(event)
        if not selected:continue
        message=EmailMessage();message['From']=os.environ['SMTP_FROM'];message['To']=sub['email'];message['Subject']='Your CertRadar learning updates'
        message.set_content('\n'.join(json.loads(e['payload'])['title'] for e in selected))
        try:
            with smtplib.SMTP_SSL(os.environ['SMTP_HOST'],int(os.environ.get('SMTP_PORT','465')),timeout=20) as smtp:
                if os.environ.get('SMTP_USER'):smtp.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD'])
                smtp.send_message(message)
            status='sent';count+=1
        except Exception:status='delivery uncertain; review before retry'
        with database() as db:
            for event in selected:db.execute('UPDATE deliveries SET status=?,sent_at=? WHERE subscriber_id=? AND notification_id=?',(status,now(),sub['id'],event['id']))
            if status=='sent':db.execute('UPDATE subscribers SET last_sent=? WHERE id=?',(now(),sub['id']))
    return {'sent':count}
